package Server;

public class Packet {
    public String sourceAdress;
    public String destAdress;
    public int sourcePort;
    public int destPort;
}
